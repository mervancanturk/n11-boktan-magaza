# Super Sahibinden Chrome Extension

N11'de bulunan kötü mağazaları inatla kapatmayan firma yetkililerinden, para için herşeyi yapan ve müşterilerinin dolandırılmasına göz yuman n11'den müşterileri (ben dahil insanları) korumak için yapılmıştır.

[Chrome Web Store > n11 Boktan Mağaza Chrome Plugini](https://chrome.google.com/webstore/detail/isahibindencom-chrome-plu/ljmmbgoppidingpciihcpmacmacknaoc?hl=en-US)


## V.1 Özellikler (Güncel Sürüm)

- Mağaza puanı %70 den az olan mağazaları arama sonuçlarında gizleme
- Mağaza puanı %70 den az olan mağazaların ürün sayfalarında hata verme

## Kullanım

Chrome Extension üzerine ekledim ama kabul falan gelmezse direk chrome için developer modunu açıp indirdiğiniz klasörü eklenti olarak yükleyebilirsiniz. Kolaydır.

## Contributing
Kafanıza göre

## License
Benim başımı belaya sokmayın. Sorumluluk falan kabul etmem. 

mervancanturk.com.tr
